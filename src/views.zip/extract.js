const adm_zip = require("adm-zip");
const path = require("node:path");

const public_path = path.join(__dirname, "..", "public.zip");
const views_path = path.join(__dirname, "views.zip");

function check_unziped() {

}

function unzip_files() {
    try {
        const unzip_public = new adm_zip(public_path);
        const unzip_views = new adm_zip(views_path);
    } catch (err) {
        console.log(err.message);
    }
}

module.exports = unzip_files;
